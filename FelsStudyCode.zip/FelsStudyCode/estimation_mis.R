library(rjags)

# ------ cross-domain gcm using beta (MAR) -------
filename1 <- "fels_data.rda"
filename2 <- "fels_est.rda"

MS <- "mar"    #"mar" / "mnar"
Nsmp <- 400     #"400/800"
MP <- "mp5"     #"mp5 / mp15"


# Load Data
load(file=paste0("Data/", MS, "/n", Nsmp,"/", MP, "/", filename1))

# number of iterations & seed for initial values
nadapt = 50000
Niter = 50000
seed = 3


initial = list(".RNG.name" = "base::Wichmann-Hill", ".RNG.seed" = seed)
dat.cd.ln <- list("N" = N, "y" = pbf, "w" = bmi, "P" = NP, "id" = id,
                  "age" = visit, "gender" = gender, "Waist" = Waist)
jags.cd.mar <- jags.model( file = "JAGS/jags_cd_ln_MAR.txt", 
                           data=dat.cd.ln, n.chains=1, n.adapt=nadapt, inits = initial)
params <- c("par")
samps.cd.mar <- coda.samples(jags.cd.mar, params, n.iter = Niter)

# save(samps.cd.ln, file=paste0("results/", MS, "/n", Nsmp,"/", MP, "/mar_", filename2))

summary(samps.cd.mar)
geweke.diag(samps.cd.mar)



# -------- cross-domain gcm using beta (MNAR) -------

filename1 <- "fels_data.rda"
filename2 <- "fels_est.rda"

MS <- "mnar"    #"mar" / "mnar"
Nsmp <- 400     #"400/800"
MP <- "mp5"     #"mp5 / mp15"


# Load Data
load(file=paste0("Data/", MS, "/n", Nsmp,"/", MP, "/", filename1))

# number of iterations & seed for initial values
nadapt = 50000
Niter = 50000
seed = 3


initial = list(".RNG.name" = "base::Wichmann-Hill", ".RNG.seed" = seed)
dat.cd.ln <- list("N" = N, "y" = pbf, "w" = bmi, "P" = NP, "id" = id,
                  "age" = visit, "gender" = gender, "Waist" = Waist,
                  "wave" = nvisit, "m" = mis_wide, "cum" = cum.vis)
jags.cd.mnar <- jags.model( file = "JAGS/jags_cd_ln_MNAR.txt", 
                            data=dat.cd.ln, n.chains=1, n.adapt=nadapt, inits = initial)
params <- c("par")
samps.cd.mnar <- coda.samples(jags.cd.mnar, params, n.iter = Niter)

# save(samps.cd.ln, file=paste0("results/", MS, "/n", Nsmp,"/", MP, "/mnar_", filename2))

summary(samps.cd.mnar)
geweke.diag(samps.cd.mnar)